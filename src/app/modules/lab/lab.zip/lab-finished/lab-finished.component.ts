import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lab-finished',
  templateUrl: './lab-finished.component.html',
  styleUrls: ['./lab-finished.component.css']
})
export class LabFinishedComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
